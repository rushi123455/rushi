# 💜 Our Journey

A romantic interactive website created to capture memories, time, music, and stories in one emotional experience.

## ✨ Features
- Love timer since a special date
- Music playlist with floating player
- Relationship timeline & photo gallery
- Smooth animations and romantic dark theme

## 🛠 Tech Stack
HTML, CSS, JavaScript

## ▶️ How to Run
Open `index.html` in your browser.

> Built with love, for someone special.
